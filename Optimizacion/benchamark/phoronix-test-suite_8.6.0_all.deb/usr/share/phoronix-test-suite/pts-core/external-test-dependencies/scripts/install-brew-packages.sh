#!/bin/sh

# Brew package installation

brew install $*
