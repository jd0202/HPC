#!/bin/sh
pkg install $*
