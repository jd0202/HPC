#!/bin/sh

#mports pkg
mport install $*

